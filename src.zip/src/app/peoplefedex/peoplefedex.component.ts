import { Component } from '@angular/core';

@Component({
  selector: 'app-peoplefedex',
  standalone: true,
  imports: [],
  templateUrl: './peoplefedex.component.html',
  styleUrl: './peoplefedex.component.scss'
})
export class PeoplefedexComponent {

}
