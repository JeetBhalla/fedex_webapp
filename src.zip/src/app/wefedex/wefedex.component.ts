import { Component } from '@angular/core';

@Component({
  selector: 'app-wefedex',
  standalone: true,
  imports: [],
  templateUrl: './wefedex.component.html',
  styleUrl: './wefedex.component.scss'
})
export class WefedexComponent {

}
