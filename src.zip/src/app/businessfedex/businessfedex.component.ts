import { Component } from '@angular/core';

@Component({
  selector: 'app-businessfedex',
  standalone: true,
  imports: [],
  templateUrl: './businessfedex.component.html',
  styleUrl: './businessfedex.component.scss'
})
export class BusinessfedexComponent {

}
